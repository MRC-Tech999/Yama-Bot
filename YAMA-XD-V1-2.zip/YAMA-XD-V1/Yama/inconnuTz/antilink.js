import { serialize } from '../../lib/Serializer.js';
import config from '../../config.cjs';

const antilinkSettings = {}; // { groupId: { antilink: false, action: null, warnings: {} } }

export const handleAntilink = async (m, sock, logger, isBotAdmins, isAdmins, isCreator) => {
    const contextInfoHans = {
        contextInfo: {
            forwardingScore: 5,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: "YAMA-XD-V1",
                newsletterJid: "120363397722863547@newsletter",
            },
        }
    };

    const PREFIX = /^[\\/!#.]/;
    const isCOMMAND = (body) => PREFIX.test(body);
    const prefixMatch = isCOMMAND(m.body) ? m.body.match(PREFIX) : null;
    const prefix = prefixMatch ? prefixMatch[0] : '/';
    const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';

    if (!antilinkSettings[m.from]) {
        antilinkSettings[m.from] = { antilink: false, action: null, warnings: {} };
    }

    // Command Handler
    if (cmd === 'antilink') {
        if (!m.isGroup) return reply(`━━⚠️ *Group Only Command* ⚠️━━`);
        if (!isBotAdmins) return reply(`━━⚠️ *I need admin permission to work!* ⚠️━━`);
        if (!isAdmins) return reply(`━━⚠️ *Only Admins can use Antilink settings!* ⚠️━━`);

        const args = m.body.slice(prefix.length + cmd.length).trim().split(/\s+/);
        const subcmd = args[0] ? args[0].toLowerCase() : '';

        switch (subcmd) {
            case 'on':
                antilinkSettings[m.from].antilink = true;
                antilinkSettings[m.from].action = null;
                return reply(
                    `━⚡ *YAMA-XD-V1 Antilink Activated* ⚡━\n` +
                    `> 🔹 Choose an action:\n` +
                    `> 🚫 ${prefix}antilink action delete 📌only for delete\n` +
                    `> ⚠️ ${prefix}antilink action warn 📌for warning 4 to kick\n` +
                    `> 🚪 ${prefix}antilink action kick 📌for kick user\n` +
                    `━━━━━━━━━━━━━━━━━━━━━━`
                );

            case 'off':
                antilinkSettings[m.from] = { antilink: false, action: null, warnings: {} };
                return reply(`━❌ *YAMA-XD-V1 Antilink Deactivated* ❌━`);

            case 'action':
                if (!antilinkSettings[m.from].antilink) {
                    return reply(`━━⚠️ *Antilink is OFF*\n> Please turn on using ${prefix}antilink on ⚠️━━`);
                }
                const actionType = args[1] ? args[1].toLowerCase() : '';
                if (['delete', 'warn', 'kick'].includes(actionType)) {
                    antilinkSettings[m.from].action = actionType;
                    return reply(`━━✅ *Antilink action set to ${actionType.toUpperCase()}* ✅━━`);
                } else {
                    return reply(
                        `━━⚡ *Invalid Action!*\n` +
                        `> 🚫 ${prefix}antilink action delete\n` +
                        `> ⚠️ ${prefix}antilink action warn\n` +
                        `> 🚪 ${prefix}antilink action kick ⚡━━`
                    );
                }

            default:
                return reply(
                    `━━📌 *YAMA-XD-V1 Antilink Usage:*\n` +
                    `> ${prefix}antilink on\n` +
                    `> ${prefix}antilink off\n` +
                    `> ${prefix}antilink action delete | warn | kick 📌━━`
                );
        }
    }

    // Link Detection
    if (antilinkSettings[m.from].antilink && m.body && /(https?:\/\/|chat\.whatsapp\.com\/)/i.test(m.body)) {
        if (!isBotAdmins) return;

        let groupLink;
        try {
            const code = await sock.groupInviteCode(m.from);
            groupLink = `https://chat.whatsapp.com/${code}`;
        } catch {
            groupLink = '';
        }

        const isOwnGroupLink = new RegExp(groupLink, 'i').test(m.body);

        if (isOwnGroupLink) return reply(`━━✅ *Own Group Link Detected, Safe!* ✅━━`);
        if (isAdmins || isCreator) return reply(`━━✅ *Admin Message, Ignored!* ✅━━`);

        // Take action
        const action = antilinkSettings[m.from].action;
        if (!action) {
            return reply(
                `━━⚡ *No Action Set!*\n` +
                `> Set action using:\n` +
                `> 🚫 ${prefix}antilink action delete\n` +
                `> ⚠️ ${prefix}antilink action warn\n` +
                `> 🚪 ${prefix}antilink action kick ⚡━━`
            );
        }

        await sock.sendMessage(m.from, { delete: m.key });

        const mentionTag = `@${m.sender.split('@')[0]}`;

        switch (action) {
            case 'delete':
                return send(
                    `━━🚫 *${mentionTag} Link detected and deleted!* 🚫━━`,
                    [m.sender]
                );

            case 'warn':
                let userWarn = antilinkSettings[m.from].warnings[m.sender] || 0;
                userWarn += 1;
                antilinkSettings[m.from].warnings[m.sender] = userWarn;

                const maxWarnings = config.ANTILINK_WARNINGS || 4;
                if (userWarn >= maxWarnings) {
                    await sock.groupParticipantsUpdate(m.from, [m.sender], 'remove');
                    delete antilinkSettings[m.from].warnings[m.sender];
                    return send(`━━🚪 *${mentionTag} kicked after ${maxWarnings} warnings!* 🚪━━`, [m.sender]);
                } else {
                    return send(`━━⚠️ *Warning ${userWarn}/${maxWarnings}*\n${mentionTag} Links are not allowed! ⚠️━━`, [m.sender]);
                }

            case 'kick':
                await sock.groupParticipantsUpdate(m.from, [m.sender], 'remove');
                return send(`━━🚪 *${mentionTag} kicked for sending a link!* 🚪━━`, [m.sender]);

            default:
                return;
        }
    }

    // Helpers
    async function reply(text) {
        return await sock.sendMessage(m.from, { text, ...contextInfoHans }, { quoted: m });
    }

    async function send(text, mentions = []) {
        return await sock.sendMessage(m.from, { text, mentions, ...contextInfoHans }, { quoted: m });
    }
};
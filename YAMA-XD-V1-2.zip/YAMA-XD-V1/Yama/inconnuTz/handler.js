import { serialize, decodeJid } from '../../lib/Serializer.js';
import path from 'path';
import fs from 'fs/promises';
import config from '../../config.cjs';
import { smsg } from '../../lib/myfunc.cjs';
import { handleAntilink } from './antilink.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Fonction pour obtenir les admins du groupe
export const getGroupAdmins = (participants = []) => 
    participants.filter(p => p.admin === "superadmin" || p.admin === "admin").map(p => p.id);

const Handler = async (chatUpdate, sock, logger) => {
    try {
        if (chatUpdate.type !== 'notify') return;

        const m = serialize(JSON.parse(JSON.stringify(chatUpdate.messages[0])), sock, logger);
        if (!m.message) return;

        const { isGroup, sender, from, body } = m;

        // Obtenir participants & admins
        const participants = isGroup ? await sock.groupMetadata(from).then(md => md.participants) : [];
        const groupAdmins = isGroup ? getGroupAdmins(participants) : [];
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        const isBotAdmins = isGroup ? groupAdmins.includes(botId) : false;
        const isAdmins = isGroup ? groupAdmins.includes(sender) : false;

        // Commande
        const PREFIX = /^[\\/!#.]/;
        const isCOMMAND = PREFIX.test(body || '');
        const prefixMatch = isCOMMAND ? body.match(PREFIX) : null;
        const prefix = prefixMatch ? prefixMatch[0] : '/';
        const cmd = body.startsWith(prefix) ? body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
        const text = body.slice(prefix.length + cmd.length).trim();

        // Auto lecture des statuts
        if (m.key?.remoteJid === 'status@broadcast' && config.AUTO_STATUS_SEEN) {
            await sock.readMessages([m.key]);
        }

        // Vérif Owner ou Bot
        const botNumber = await sock.decodeJid(sock.user.id);
        const ownerNumber = config.OWNER_NUMBER + '@s.whatsapp.net';
        const isCreator = [ownerNumber, botNumber].includes(sender);

        // Si bot en mode privé
        if (!sock.public && !isCreator) return;

        // Exécution des protections
        await handleAntilink(m, sock, logger, isBotAdmins, isAdmins, isCreator);

        // Debug : log le message complet (tu peux le désactiver)
        console.log(m);

        // Charger dynamiquement tous les plugins du dossier inconnuTech
        const pluginDir = path.join(__dirname, '..', 'inconnuTech');
        const pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));

        await Promise.all(pluginFiles.map(async (file) => {
            const pluginPath = path.join(pluginDir, file);
            try {
                const pluginModule = await import(`file://${pluginPath}`);
                const loadPlugins = pluginModule.default;
                await loadPlugins(m, sock);
            } catch (err) {
                console.error(`Erreur dans plugin: ${pluginPath}`, err);
            }
        }));

    } catch (e) {
        console.error(e);
    }
};

export default Handler;
import config from '../../config.cjs';

const ping = async (m, sock) => {
  const prefix = config.PREFIX;
  const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
  const text = m.body.slice(prefix.length + cmd.length).trim();

  if (cmd === "menu") {
    const start = new Date().getTime();
    await m.React('👨‍💻');
    const end = new Date().getTime();
    const responseTime = (end - start) / 1000;

    const menuText = `
╭─〔 *✦ YAMA-XD-V1 ✦* 〕─◆
│
│ ✪ *Owner*   : ${config.OWNER_NAME}
│ ✪ *User*    : ${m.pushName}
│ ✪ *Baileys* : Multi Device
│ ✪ *Mode*    : ${mode}
│ ✪ *DEV*     : *YAMA-TECH*
│ ✪ *Prefix*  : [${prefix}] 
╰──────────────────

*✦ ${m.pushname} WELCOME TO YAMA-XD-V1 ✦*
━━━━━━━━━━━━━━━━━━━━

╭─〔 ✦ Download Menu ✦ 〕─◆
│ ⭒ tiktok
│ ⭒ ytmp4doc
│ ⭒ ytmp3doc
│ ⭒ video
│ ⭒ song
│ ⭒ play
│ ⭒ ytmp4
│ ⭒ ytmp3
│ ⭒ insta
│ ⭒ gdrive
│ ⭒ gitclone
│ ⭒ mediafire
│ ⭒ pinterestdl
│ ⭒ facebook
│ ⭒ apk
╰──────────────────◆

╭─〔 ✦ Converter Menu ✦ 〕─◆
│ ⭒ mp3
│ ⭒ emojimix
│ ⭒ dbinary
│ ⭒ ebinary
│ ⭒ attp3
│ ⭒ attp2
│ ⭒ attp
╰──────────────────◆

╭─〔 ✦ AI Menu ✦ 〕─◆
│ ⭒ gemini
│ ⭒ remini
│ ⭒ dalle
│ ⭒ gpt
│ ⭒ report
│ ⭒ bug
│ ⭒ ai
╰──────────────────◆

╭─〔 ✦ Tools Menu ✦ 〕─◆
│ ⭒ tts
│ ⭒ trt
│ ⭒ checkmail
│ ⭒ tempmail
│ ⭒ calculator
╰──────────────────◆

╭─〔 ✦ Group Menu ✦ 〕─◆
│ ⭒ getbio
│ ⭒ antilink
│ ⭒ antitoxic
│ ⭒ tagall
│ ⭒ hidetag
│ ⭒ demoteall
│ ⭒ demote
│ ⭒ promoteall
│ ⭒ promote
│ ⭒ kickall
│ ⭒ kick
│ ⭒ add
│ ⭒ welcome
│ ⭒ gcsetting
│ ⭒ group
│ ⭒ setdesc
│ ⭒ setname
│ ⭒ setppgc
│ ⭒ linkgc
╰──────────────────◆

╭─〔 ✦ Search Menu ✦ 〕─◆
│ ⭒ lyrics
│ ⭒ ringtone
│ ⭒ ytsearch
│ ⭒ wikimedia
│ ⭒ wallpaper
│ ⭒ pinterest
│ ⭒ gimage
│ ⭒ google
│ ⭒ imdb
│ ⭒ yts
│ ⭒ play
╰──────────────────◆

╭─〔 ✦ Main Menu ✦ 〕─◆
│ ⭒ infobot
│ ⭒ menu
│ ⭒ owner
│ ⭒ alive
│ ⭒ ping
╰──────────────────◆

╭─〔 ✦ Owner Menu ✦ 〕─◆
│ ⭒ autosview
│ ⭒ autoread
│ ⭒ alwaysonline
│ ⭒ autotyping
│ ⭒ setnamebot
│ ⭒ setstatus
│ ⭒ anticall
│ ⭒ setppbot
│ ⭒ unblock
│ ⭒ block
│ ⭒ leave
│ ⭒ join
╰──────────────────◆

╭─〔 ✦ Stalk Menu ✦ 〕─◆
│ ⭒ githubstalk
│ ⭒ instastalk
│ ⭒ truecaller
╰──────────────────◆

> ©️BY YAMA-TECH
`;

    await sock.sendMessage(m.from, {
      image: { url: 'https://files.catbox.moe/j2zhuw.jpeg' },
      caption: menuText.trim(),
      contextInfo: {
        forwardingScore: 5,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterName: "YAMA-TECH",
          newsletterJid: "120363397722863547@newsletter",
        },
      }
    }, { quoted: m });
  }
};

export default ping;
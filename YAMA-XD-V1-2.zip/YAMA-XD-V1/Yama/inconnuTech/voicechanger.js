import { exec } from 'child_process';
import fs from 'fs';
import { getRandom } from '../../lib/myfunc.cjs';
import config from '../../config.cjs';

const audioEffects = async (m, gss) => {
  try {
    const prefix = config.PREFIX;
    const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
    const text = m.body.slice(prefix.length + cmd.length).trim();

    const validCommands = ['bass', 'blown', 'deep', 'earrape', 'hansfast', 'fat', 'nightcore', 'reverse', 'robot', 'slow', 'smooth', 'tupai'];
    if (!validCommands.includes(cmd)) return;

    const effects = {
      bass: '-af equalizer=f=54:width_type=o:width=2:g=20',
      blown: '-af acrusher=.1:1:64:0:log',
      deep: '-af atempo=4/4,asetrate=44500*2/3',
      earrape: '-af volume=12',
      fast: '-filter:a "atempo=1.63,asetrate=44100"',
      fat: '-filter:a "atempo=1.6,asetrate=22100"',
      nightcore: '-filter:a atempo=1.06,asetrate=44100*1.25',
      reverse: '-filter_complex "areverse"',
      robot: '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"',
      slow: '-filter:a "atempo=0.7,asetrate=44100"',
      smooth: '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"',
      tupai: '-filter:a "atempo=0.5,asetrate=65100"',
    };

    const effect = effects[cmd];

    if (!m.quoted || m.quoted.mtype !== 'audioMessage') {
      return m.reply(`Reply to the audio you want to change with a caption *${prefix + cmd}*`);
    }

    m.reply('Please wait...');
    const media = await m.quoted.download();
    const mediaPath = `./${getRandom('.webm')}`;
    fs.writeFileSync(mediaPath, media);

    const outputPath = `./${getRandom('.mp3')}`;

    exec(`ffmpeg -i ${mediaPath} ${effect} ${outputPath}`, (err, stderr, stdout) => {
      fs.unlinkSync(mediaPath);
      if (err) {
        console.error('Error:', err);
        return m.reply('An error occurred while processing the audio.');
      }
      const buff = fs.readFileSync(outputPath);
      gss.sendMessage(m.from, { audio: buff, mimetype: 'audio/mpeg' }, { quoted: m });
      fs.unlinkSync(outputPath);
    });

  } catch (e) {
    console.error('Error:', e);
    m.reply('An error occurred while processing the command.');
  }
};

export default audioEffects;
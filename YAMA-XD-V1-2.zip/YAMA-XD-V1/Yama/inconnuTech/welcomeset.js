import config from '../../config.cjs';
import fs from 'fs';

const WELCOME_CONFIG_PATH = './lib/welcomeConfig.json';

// Charger la configuration depuis un fichier
const loadWelcomeConfig = () => {
  if (!fs.existsSync(WELCOME_CONFIG_PATH)) {
    fs.writeFileSync(WELCOME_CONFIG_PATH, JSON.stringify({ WELCOME: true }), 'utf-8');
  }
  return JSON.parse(fs.readFileSync(WELCOME_CONFIG_PATH, 'utf-8'));
};

// Sauvegarder la configuration dans un fichier
const saveWelcomeConfig = (configData) => {
  fs.writeFileSync(WELCOME_CONFIG_PATH, JSON.stringify(configData, null, 2), 'utf-8');
};

const gcEvent = async (m, Matrix) => {
  const prefix = config.PREFIX;
  const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
  const text = m.body.slice(prefix.length + cmd.length).trim();

  if (cmd === 'welcome') {
    if (!m.isGroup) return m.reply("*📛 THIS COMMAND CAN ONLY BE USED IN GROUPS*");
    
    const groupMetadata = await Matrix.groupMetadata(m.from);
    const participants = groupMetadata.participants;
    const botNumber = await Matrix.decodeJid(Matrix.user.id);
    const botAdmin = participants.find(p => p.id === botNumber)?.admin;
    const senderAdmin = participants.find(p => p.id === m.sender)?.admin;

    if (!botAdmin) return m.reply("*📛 BOT MUST BE AN ADMIN TO USE THIS COMMAND*");
    if (!senderAdmin) return m.reply("*📛 YOU MUST BE AN ADMIN TO USE THIS COMMAND*");

    let responseMessage;

    const welcomeConfig = loadWelcomeConfig();

    if (text === 'on') {
      welcomeConfig.WELCOME = true;
      saveWelcomeConfig(welcomeConfig);
      responseMessage = "WELCOME & LEFT message has been enabled.";
    } else if (text === 'off') {
      welcomeConfig.WELCOME = false;
      saveWelcomeConfig(welcomeConfig);
      responseMessage = "WELCOME & LEFT message has been disabled.";
    } else {
      responseMessage = "Usage:\n- `WELCOME on`: Enable WELCOME & LEFT message\n- `WELCOME off`: Disable WELCOME & LEFT message";
    }

    try {
      await Matrix.sendMessage(m.from, { text: responseMessage }, { quoted: m });
    } catch (error) {
      console.error("Error processing your request:", error);
      await Matrix.sendMessage(m.from, { text: 'Error processing your request.' }, { quoted: m });
    }
  }
};

export default gcEvent;